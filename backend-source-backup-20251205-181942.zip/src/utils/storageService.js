﻿/**
 * Wrapper so code requiring ../utils/storageService will work.
 * This re-exports the main implementation from ../services/storageService.
 */
module.exports = require("../services/storageService");
